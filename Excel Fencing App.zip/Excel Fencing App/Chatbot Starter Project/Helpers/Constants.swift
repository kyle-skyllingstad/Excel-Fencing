//
//  Constants.swift
//  Excel Fencing
//
//  Created by Kyle Skyllingstad on 6/10/20.
//

import Foundation

struct Constants {
    
    struct Storyboard {
        
        static let ViewController5 = "VC5"
        
    }
    
    
    
}
